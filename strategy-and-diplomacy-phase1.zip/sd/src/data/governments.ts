import { Government, Ideology } from '../types'

// Data-driven per spec section 5 — these are definitions, not hard-coded
// logic. Adding a new government/ideology means adding a row here.
export const GOVERNMENTS: Government[] = [
  { id: 'federal_republic', name: 'Federal Republic' },
  { id: 'parliamentary_republic', name: 'Parliamentary Republic' },
  { id: 'presidential_republic', name: 'Presidential Republic' },
  { id: 'constitutional_monarchy', name: 'Constitutional Monarchy' },
  { id: 'absolute_monarchy', name: 'Absolute Monarchy' },
  { id: 'military_government', name: 'Military Government' },
  { id: 'one_party_state', name: 'One-Party State' },
  { id: 'federation', name: 'Federation' },
  { id: 'confederation', name: 'Confederation' },
]

export const IDEOLOGIES: Ideology[] = [
  { id: 'liberal_democratic', name: 'Liberal Democratic' },
  { id: 'social_democratic', name: 'Social Democratic' },
  { id: 'conservative_nationalist', name: 'Conservative Nationalist' },
  { id: 'state_socialist', name: 'State Socialist' },
  { id: 'technocratic', name: 'Technocratic' },
  { id: 'theocratic', name: 'Theocratic' },
  { id: 'authoritarian_centrist', name: 'Authoritarian Centrist' },
]
