import { Trait } from '../types'

export const STARTING_BUDGET = 30

export const TRAITS: Trait[] = [
  {
    id: 'industrial_power',
    name: 'Industrial Power',
    description: 'Large existing manufacturing base. Higher starting industry.',
    cost: 10,
  },
  {
    id: 'resource_rich',
    name: 'Resource Rich',
    description: 'Significant oil and mineral reserves within your territory.',
    cost: 8,
  },
  {
    id: 'militarised_society',
    name: 'Militarised Society',
    description: 'Higher starting military readiness and recruitment capacity.',
    cost: 8,
  },
  {
    id: 'financial_hub',
    name: 'Financial Hub',
    description: 'Strong banking sector. Higher starting treasury and trade income.',
    cost: 9,
  },
  {
    id: 'technological_edge',
    name: 'Technological Edge',
    description: 'Advanced starting research infrastructure.',
    cost: 9,
  },
  {
    id: 'agricultural_heartland',
    name: 'Agricultural Heartland',
    description: 'Fertile territory. Strong food production and export potential.',
    cost: 6,
  },
  {
    id: 'economic_weakness',
    name: 'Economic Weakness',
    description: 'Underdeveloped economy. Lower starting production.',
    cost: -5,
  },
  {
    id: 'political_instability',
    name: 'Political Instability',
    description: 'Fractured domestic politics. Lower starting stability.',
    cost: -6,
  },
  {
    id: 'weak_military',
    name: 'Weak Military Tradition',
    description: 'Minimal standing forces at campaign start.',
    cost: -5,
  },
  {
    id: 'isolated_geography',
    name: 'Isolated Geography',
    description: 'Poor trade access. Lower starting diplomatic reach.',
    cost: -4,
  },
]
