import { WorldData, NationDraft } from '../types'
import { GOVERNMENTS, IDEOLOGIES } from '../data/governments'
import { TRAITS } from '../data/traits'

interface Props {
  world: WorldData
  selectedHexId: string | null
  playerCountryId: string
  nation: NationDraft
}

export default function RightPanel({ world, selectedHexId, playerCountryId, nation }: Props) {
  const hex = selectedHexId ? world.hexes[selectedHexId] : null
  const hexCountry = hex?.countryId ? world.countries[hex.countryId] : null
  const isPlayerHex = hex?.countryId === playerCountryId

  const government = GOVERNMENTS.find((g) => g.id === nation.governmentId)
  const ideology = IDEOLOGIES.find((i) => i.id === nation.ideologyId)
  const activeTraits = TRAITS.filter((t) => nation.traitIds.includes(t.id))
  const playerCountry = world.countries[playerCountryId]

  return (
    <div className="right-panel">
      {hexCountry ? (
        <>
          <h2>{hexCountry.name}</h2>
          <div className="panel-sub">{isPlayerHex ? 'Your Territory' : 'Sector Status'}</div>
          <div className="stat-row"><span className="k">Controller</span><span className="v">{hexCountry.name}</span></div>
          <div className="stat-row"><span className="k">Territory Size</span><span className="v">{hexCountry.hexIds.length} provinces</span></div>
          {isPlayerHex && (
            <>
              <div className="stat-row"><span className="k">Government</span><span className="v">{government?.name}</span></div>
              <div className="stat-row"><span className="k">Ideology</span><span className="v">{ideology?.name}</span></div>
              <div className="stat-row"><span className="k">Leader</span><span className="v">{nation.leaderTitle} {nation.leaderName}</span></div>
              <div className="stat-row"><span className="k">Currency</span><span className="v">{nation.currencyName}</span></div>
            </>
          )}
        </>
      ) : (
        <>
          <h2>{nation.commonName}</h2>
          <div className="panel-sub">National Overview</div>
          <div className="stat-row"><span className="k">Official Name</span><span className="v">{nation.officialName}</span></div>
          <div className="stat-row"><span className="k">Government</span><span className="v">{government?.name}</span></div>
          <div className="stat-row"><span className="k">Ideology</span><span className="v">{ideology?.name}</span></div>
          <div className="stat-row"><span className="k">Territory</span><span className="v">{playerCountry?.hexIds.length ?? 0} provinces</span></div>
        </>
      )}

      {isPlayerHex && activeTraits.length > 0 && (
        <div style={{ marginTop: 14 }}>
          <div className="panel-sub">National Traits</div>
          {activeTraits.map((t) => (
            <div key={t.id} className="stat-row"><span className="k">{t.name}</span><span className="v">{t.cost > 0 ? `-${t.cost}` : `+${Math.abs(t.cost)}`}</span></div>
          ))}
        </div>
      )}

      <div className="phase-note">
        Population, resource output, stability, and military presence are simulated
        starting in Phase 2 (Economy) and Phase 3 (Military). This panel currently
        shows only identity and territory data, which is what Phase 1 actually builds.
      </div>
    </div>
  )
}
