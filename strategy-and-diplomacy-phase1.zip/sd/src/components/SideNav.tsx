const ITEMS: { label: string; locked: string | null }[] = [
  { label: 'Overview', locked: null },
  { label: 'Economy', locked: 'Phase 2' },
  { label: 'Industry', locked: 'Phase 2' },
  { label: 'Research', locked: 'Phase 3' },
  { label: 'Military', locked: 'Phase 3' },
  { label: 'Diplomacy', locked: 'Phase 5' },
  { label: 'Politics', locked: 'Phase 6' },
  { label: 'Intelligence', locked: 'Phase 6' },
]

export default function SideNav() {
  return (
    <div className="sidenav">
      {ITEMS.map((item) => (
        <div key={item.label} className={`nav-item ${item.locked ? 'locked' : 'active'}`}>
          {item.label}
          {item.locked && <span className="lock-note">{item.locked} — not built yet</span>}
        </div>
      ))}
    </div>
  )
}
