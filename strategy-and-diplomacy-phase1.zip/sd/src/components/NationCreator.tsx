import { useMemo, useState } from 'react'
import { useGameStore } from '../state/gameStore'
import { GOVERNMENTS, IDEOLOGIES } from '../data/governments'
import { STARTING_BUDGET, TRAITS } from '../data/traits'
import { NationDraft } from '../types'

export default function NationCreator() {
  const startCampaign = useGameStore((s) => s.startCampaign)
  const goToMenu = useGameStore((s) => s.goToMenu)

  const [officialName, setOfficialName] = useState('')
  const [commonName, setCommonName] = useState('')
  const [capitalName, setCapitalName] = useState('')
  const [leaderName, setLeaderName] = useState('')
  const [leaderTitle, setLeaderTitle] = useState('President')
  const [currencyName, setCurrencyName] = useState('')
  const [demonym, setDemonym] = useState('')
  const [motto, setMotto] = useState('')
  const [color, setColor] = useState('#4a9d94')
  const [governmentId, setGovernmentId] = useState(GOVERNMENTS[0].id)
  const [ideologyId, setIdeologyId] = useState(IDEOLOGIES[0].id)
  const [traitIds, setTraitIds] = useState<string[]>([])

  const spent = useMemo(
    () => TRAITS.filter((t) => traitIds.includes(t.id)).reduce((sum, t) => sum + t.cost, 0),
    [traitIds]
  )
  const remaining = STARTING_BUDGET - spent

  function toggleTrait(id: string, cost: number) {
    const isSelected = traitIds.includes(id)
    if (isSelected) {
      setTraitIds(traitIds.filter((t) => t !== id))
      return
    }
    // Refund traits (negative cost) never blocked; positive-cost traits
    // blocked if they'd push the budget negative.
    if (cost > 0 && remaining - cost < 0) return
    setTraitIds([...traitIds, id])
  }

  const canConfirm = officialName.trim().length > 0 && commonName.trim().length > 0

  function handleConfirm() {
    const draft: NationDraft = {
      officialName: officialName.trim(),
      commonName: commonName.trim(),
      capitalName: capitalName.trim() || 'Capital City',
      leaderName: leaderName.trim() || 'Unnamed Leader',
      leaderTitle: leaderTitle.trim() || 'Leader',
      currencyName: currencyName.trim() || 'Credit',
      demonym: demonym.trim() || commonName.trim(),
      motto: motto.trim(),
      color,
      governmentId,
      ideologyId,
      traitIds,
    }
    startCampaign(draft)
  }

  return (
    <div className="creator-screen">
      <h1>Found Your Nation</h1>
      <div className="subtitle">Every field here is yours to define — nothing is locked to a preset country.</div>

      <div className="budget-bar">
        <span>National creation budget</span>
        <span className={`amount mono ${remaining < 0 ? 'negative' : ''}`}>{remaining} / {STARTING_BUDGET}</span>
      </div>

      <div className="field-group">
        <div className="section-label">Identity</div>
        <div className="two-col">
          <div className="field-row">
            <label>Official Name</label>
            <input type="text" value={officialName} onChange={(e) => setOfficialName(e.target.value)} placeholder="Federal Republic of Asteria" />
          </div>
          <div className="field-row">
            <label>Common Name</label>
            <input type="text" value={commonName} onChange={(e) => setCommonName(e.target.value)} placeholder="Asteria" />
          </div>
        </div>
        <div className="two-col">
          <div className="field-row">
            <label>Capital City</label>
            <input type="text" value={capitalName} onChange={(e) => setCapitalName(e.target.value)} placeholder="Asterport" />
          </div>
          <div className="field-row">
            <label>Demonym</label>
            <input type="text" value={demonym} onChange={(e) => setDemonym(e.target.value)} placeholder="Asterian" />
          </div>
        </div>
        <div className="field-row">
          <label>National Motto (optional)</label>
          <input type="text" value={motto} onChange={(e) => setMotto(e.target.value)} placeholder="Strength Through Unity" />
        </div>
        <div className="field-row">
          <label>National Colour</label>
          <input type="color" value={color} onChange={(e) => setColor(e.target.value)} />
        </div>
      </div>

      <div className="field-group">
        <div className="section-label">Leadership &amp; Currency</div>
        <div className="two-col">
          <div className="field-row">
            <label>Leader Name</label>
            <input type="text" value={leaderName} onChange={(e) => setLeaderName(e.target.value)} placeholder="Elena Voss" />
          </div>
          <div className="field-row">
            <label>Leader Title</label>
            <input type="text" value={leaderTitle} onChange={(e) => setLeaderTitle(e.target.value)} placeholder="President" />
          </div>
        </div>
        <div className="field-row">
          <label>Currency Name</label>
          <input type="text" value={currencyName} onChange={(e) => setCurrencyName(e.target.value)} placeholder="Asterian Crown" />
        </div>
      </div>

      <div className="field-group">
        <div className="section-label">Government</div>
        <div className="two-col">
          <div className="field-row">
            <label>Government Type</label>
            <select value={governmentId} onChange={(e) => setGovernmentId(e.target.value)}>
              {GOVERNMENTS.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
            </select>
          </div>
          <div className="field-row">
            <label>Political Ideology</label>
            <select value={ideologyId} onChange={(e) => setIdeologyId(e.target.value)}>
              {IDEOLOGIES.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
            </select>
          </div>
        </div>
      </div>

      <div className="field-group">
        <div className="section-label">National Traits (spend or refund budget)</div>
        {TRAITS.map((t) => {
          const selected = traitIds.includes(t.id)
          const disabled = !selected && t.cost > 0 && remaining - t.cost < 0
          return (
            <div
              key={t.id}
              className={`trait-card ${selected ? 'selected' : ''}`}
              style={{ opacity: disabled ? 0.4 : 1 }}
              onClick={() => !disabled && toggleTrait(t.id, t.cost)}
            >
              <input type="checkbox" checked={selected} readOnly disabled={disabled} />
              <div>
                <div className="trait-name">{t.name}</div>
                <div className="trait-desc">{t.description}</div>
              </div>
              <div className={`trait-cost mono ${t.cost > 0 ? 'cost' : 'refund'}`}>
                {t.cost > 0 ? `-${t.cost}` : `+${Math.abs(t.cost)}`}
              </div>
            </div>
          )
        })}
      </div>

      <div className="creator-actions">
        <button onClick={goToMenu}>Back</button>
        <button className="primary" disabled={!canConfirm} onClick={handleConfirm}>
          Generate World &amp; Begin
        </button>
      </div>
    </div>
  )
}
