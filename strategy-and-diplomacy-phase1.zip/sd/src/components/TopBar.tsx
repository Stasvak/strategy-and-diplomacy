import { formatClockDate, useGameStore } from '../state/gameStore'
import { GameClock } from '../types'

const SPEEDS: GameClock['speed'][] = [1, 2, 4, 8]

export default function TopBar() {
  const nation = useGameStore((s) => s.nation)
  const clock = useGameStore((s) => s.clock)
  const setSpeed = useGameStore((s) => s.setSpeed)
  const togglePause = useGameStore((s) => s.togglePause)
  const save = useGameStore((s) => s.save)

  if (!nation) return null

  return (
    <div className="topbar">
      <div className="nation-id">
        <span className="flag-swatch" style={{ background: nation.color }} />
        <span className="nation-name">{nation.commonName}</span>
      </div>

      <div className="date mono">{formatClockDate(clock.totalHours)}</div>

      <div className="speed-controls">
        <button className={clock.paused ? 'active' : ''} onClick={togglePause}>
          {clock.paused ? 'PAUSED' : 'II'}
        </button>
        {SPEEDS.map((sp) => (
          <button
            key={sp}
            className={!clock.paused && clock.speed === sp ? 'active' : ''}
            onClick={() => setSpeed(sp)}
          >
            {sp}x
          </button>
        ))}
        <button className="save-btn" onClick={save}>Save</button>
      </div>
    </div>
  )
}
