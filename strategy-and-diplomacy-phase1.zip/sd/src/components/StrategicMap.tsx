import React, { useRef, useState } from 'react'
import { WorldData } from '../types'

interface Props {
  world: WorldData
  selectedHexId: string | null
  playerCountryId: string
  onSelectHex: (hexId: string) => void
}

interface ViewState {
  x: number
  y: number
  scale: number
}

export default function StrategicMap({ world, selectedHexId, playerCountryId, onSelectHex }: Props) {
  const hostRef = useRef<HTMLDivElement>(null)
  const [view, setView] = useState<ViewState>({ x: 0, y: 0, scale: 1 })
  const dragRef = useRef<{ startX: number; startY: number; viewX: number; viewY: number } | null>(null)
  const pinchRef = useRef<number | null>(null)

  function onPointerDown(e: React.PointerEvent) {
    ;(e.target as Element).setPointerCapture(e.pointerId)
    dragRef.current = { startX: e.clientX, startY: e.clientY, viewX: view.x, viewY: view.y }
  }

  function onPointerMove(e: React.PointerEvent) {
    if (!dragRef.current) return
    const dx = e.clientX - dragRef.current.startX
    const dy = e.clientY - dragRef.current.startY
    setView((v) => ({ ...v, x: dragRef.current!.viewX + dx, y: dragRef.current!.viewY + dy }))
  }

  function onPointerUp() {
    dragRef.current = null
  }

  function onWheel(e: React.WheelEvent) {
    e.preventDefault()
    const delta = -e.deltaY * 0.001
    setView((v) => ({ ...v, scale: Math.min(4, Math.max(0.3, v.scale * (1 + delta))) }))
  }

  let dragMoved = false
  function onPointerDownTrack(e: React.PointerEvent) {
    dragMoved = false
    onPointerDown(e)
  }
  function onPointerMoveTrack(e: React.PointerEvent) {
    if (dragRef.current) dragMoved = true
    onPointerMove(e)
  }

  function handleHexClick(hexId: string) {
    if (dragMoved) return
    onSelectHex(hexId)
  }

  return (
    <div
      ref={hostRef}
      className="map-host"
      onPointerDown={onPointerDownTrack}
      onPointerMove={onPointerMoveTrack}
      onPointerUp={onPointerUp}
      onPointerLeave={onPointerUp}
      onWheel={onWheel}
    >
      <svg
        width="100%"
        height="100%"
        viewBox={`0 0 ${world.bounds.width} ${world.bounds.height}`}
        preserveAspectRatio="xMidYMid meet"
      >
        <g transform={`translate(${view.x} ${view.y}) scale(${view.scale})`}>
          <rect x={0} y={0} width={world.bounds.width} height={world.bounds.height} fill="#05070a" />

          {Object.values(world.hexes).map((hex) => {
            const country = hex.countryId ? world.countries[hex.countryId] : null
            const fill = country ? country.color : '#12181c'
            const points = hex.corners.map(([x, y]) => `${x},${y}`).join(' ')
            const isSelected = hex.id === selectedHexId
            return (
              <polygon
                key={hex.id}
                points={points}
                fill={fill}
                fillOpacity={isSelected ? 1 : 0.88}
                stroke={isSelected ? '#c7a35a' : 'none'}
                strokeWidth={isSelected ? 2 / view.scale : 0}
                onClick={() => handleHexClick(hex.id)}
                style={{ cursor: 'pointer' }}
              />
            )
          })}

          {world.borders.map((b, i) => (
            <line
              key={i}
              x1={b.a[0]} y1={b.a[1]} x2={b.b[0]} y2={b.b[1]}
              stroke={b.kind === 'coast' ? '#0a0d0f' : '#05070a'}
              strokeWidth={(b.kind === 'coast' ? 1.4 : 2.2) / view.scale}
              strokeLinecap="round"
              pointerEvents="none"
            />
          ))}

          {Object.values(world.countries).map((c) => {
            const capital = world.hexes[c.capitalHexId]
            if (!capital) return null
            return (
              <circle
                key={c.id}
                cx={capital.center[0]}
                cy={capital.center[1]}
                r={c.isPlayer ? 5 / view.scale : 3.2 / view.scale}
                fill={c.isPlayer ? '#c7a35a' : '#dfe4e6'}
                stroke="#05070a"
                strokeWidth={1 / view.scale}
                pointerEvents="none"
              />
            )
          })}
        </g>
      </svg>
    </div>
  )
}
