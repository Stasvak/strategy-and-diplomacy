import { create } from 'zustand'
import { GameClock, NationDraft, Screen, SaveFile, WorldData } from '../types'
import { generateWorld } from '../world/generateWorld'

const SAVE_KEY = 'sd_save_v1'

interface GameStore {
  screen: Screen
  world: WorldData | null
  playerCountryId: string | null
  nation: NationDraft | null
  clock: GameClock
  selectedHexId: string | null

  goToCreator: () => void
  goToMenu: () => void
  startCampaign: (draft: NationDraft) => void
  selectHex: (hexId: string | null) => void
  setSpeed: (speed: GameClock['speed']) => void
  togglePause: () => void
  tick: (deltaRealSeconds: number) => void
  save: () => void
  load: () => boolean
  hasSave: () => boolean
}

function formatlessInitialClock(): GameClock {
  return { totalHours: 0, paused: false, speed: 1 }
}

export const useGameStore = create<GameStore>((set, get) => ({
  screen: 'menu',
  world: null,
  playerCountryId: null,
  nation: null,
  clock: formatlessInitialClock(),
  selectedHexId: null,

  goToCreator: () => set({ screen: 'creator' }),
  goToMenu: () => set({ screen: 'menu' }),

  startCampaign: (draft: NationDraft) => {
    const seed = Math.floor(Math.random() * 1_000_000)
    const { world, neutralCountryIds } = generateWorld(seed, draft.color)
    const pool = neutralCountryIds.length > 0 ? neutralCountryIds : Object.keys(world.countries)
    const chosenId = pool[Math.floor(Math.random() * pool.length)]
    const chosen = world.countries[chosenId]
    chosen.name = draft.commonName || draft.officialName
    chosen.color = draft.color
    chosen.isPlayer = true

    set({
      world,
      playerCountryId: chosenId,
      nation: draft,
      clock: formatlessInitialClock(),
      selectedHexId: chosen.capitalHexId,
      screen: 'game',
    })
  },

  selectHex: (hexId) => set({ selectedHexId: hexId }),

  setSpeed: (speed) => set((s) => ({ clock: { ...s.clock, speed, paused: false } })),

  togglePause: () => set((s) => ({ clock: { ...s.clock, paused: !s.clock.paused } })),

  tick: (deltaRealSeconds) => {
    const { clock } = get()
    if (clock.paused) return
    const hoursPerRealSecond = clock.speed // 1x = 1 in-game hour per real second
    set({ clock: { ...clock, totalHours: clock.totalHours + deltaRealSeconds * hoursPerRealSecond } })
  },

  save: () => {
    const { nation, world, playerCountryId, clock } = get()
    if (!nation || !world || !playerCountryId) return
    const save: SaveFile = { version: 1, nation, world, playerCountryId, clock }
    localStorage.setItem(SAVE_KEY, JSON.stringify(save))
  },

  load: () => {
    const raw = localStorage.getItem(SAVE_KEY)
    if (!raw) return false
    try {
      const save = JSON.parse(raw) as SaveFile
      set({
        nation: save.nation,
        world: save.world,
        playerCountryId: save.playerCountryId,
        clock: save.clock,
        selectedHexId: save.world.countries[save.playerCountryId]?.capitalHexId ?? null,
        screen: 'game',
      })
      return true
    } catch {
      return false
    }
  },

  hasSave: () => !!localStorage.getItem(SAVE_KEY),
}))

// Converts accumulated simulation hours into a readable in-campaign date.
// Campaign start is an arbitrary fictional epoch, not tied to real dates.
export function formatClockDate(totalHours: number): string {
  const startYear = 1
  const hoursPerDay = 24
  const daysPerMonth = 30
  const monthsPerYear = 12

  const totalDays = Math.floor(totalHours / hoursPerDay)
  const hourOfDay = Math.floor(totalHours % hoursPerDay)
  const year = startYear + Math.floor(totalDays / (daysPerMonth * monthsPerYear))
  const dayInYear = totalDays % (daysPerMonth * monthsPerYear)
  const month = Math.floor(dayInYear / daysPerMonth) + 1
  const day = (dayInYear % daysPerMonth) + 1

  const hh = String(hourOfDay).padStart(2, '0')
  return `Year ${year}, Month ${month}, Day ${day} — ${hh}:00`
}
