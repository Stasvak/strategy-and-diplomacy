# Strategy & Diplomacy — Phase 1

A real-time grand strategy prototype. This is the first vertical slice
described in the project's Phase 1 scope: nation creation, a procedurally
generated world map, and a live game clock. It is intentionally **not**
the full 52-section design document — see "What's not built yet" below.

## Stack
- React + TypeScript + Vite
- Zustand for state
- Plain SVG for the map (organic hex-mesh generator, not a grid of squares)
- No backend yet — everything runs client-side, saves to `localStorage`

## Setup
```bash
npm install
npm run dev       # local dev server
npm run build     # production build to /dist
```

## Deploying to GitHub Pages
1. Push this repo to GitHub.
2. In `vite.config.ts`, set `base` to `/your-repo-name/` (or `/` if this repo
   is named `yourusername.github.io`).
3. Repo **Settings → Pages** → Source: **GitHub Actions**.
4. Push to `main` — `.github/workflows/deploy.yml` builds and deploys.

## What's actually implemented
- **Main menu** with New Campaign / Continue Campaign / (disabled) Multiplayer
- **Nation creator**: full custom identity (names, capital, leader, currency,
  motto, colour), government type, ideology, and a budget-based trait system
  (positive-cost traits consume budget, negative-cost traits refund it)
- **Procedural world map**: an organic hex-mesh landmass (jittered so it does
  not look like a grid), auto-partitioned into ~10–18 countries via a
  Voronoi-style nearest-seed assignment, with real coastline/border line
  extraction — your chosen nation is assigned one of the generated countries
  and renamed/recoloured to match your creation
- **Live real-time clock**: continuous simulation time (not turns), with
  pause and 1x/2x/4x/8x speed controls
- **Map interaction**: pan (drag), zoom (wheel/pinch), click-to-select a
  province, showing controller and territory size
- **Save/Load**: full campaign state to `localStorage` (single browser only
  — this is not multiplayer persistence)

## What's NOT built yet (do not assume otherwise)
Per the project's own phase plan, these are separate phases and this build
does not fake them:
- Economy, industry, trade, resources (Phase 2)
- Research, military unit designer, production (Phase 3)
- Movement, combat, logistics, supply, front lines (Phase 4)
- Diplomacy, treaties, embargoes, alliances (Phase 5)
- Politics, public opinion, events, intelligence (Phase 6)
- AI country behavior (Phase 7)
- Multiplayer: authentication, lobbies, a server-authoritative backend,
  and a database (Phase 8) — this is the biggest remaining piece of work
  and cannot be a static GitHub Pages file; it needs a real server
- Art/animation/sound polish (Phase 9)

The left nav in-game shows every locked system explicitly labeled with
which phase it belongs to, rather than a dead button pretending to work.

## Architecture notes for continuing development
- `src/world/generateWorld.ts` — the map generator. Deterministic per seed;
  swap the seed source or continent parameters to change the world shape.
- `src/state/gameStore.ts` — single source of truth (Zustand). This is
  where Phase 2+ systems (economy ticks, research progress, etc.) should
  hook into the same `tick()` loop already driving the clock.
- `src/types.ts` — shared types. Extend `WorldCountry` and add new
  data-driven definition files (like `data/governments.ts`) rather than
  hard-coding new categories into components, per the spec's data-driven
  requirement (section 30/45).
- When Phase 8 (multiplayer) starts, the client/server split matters: this
  repo should become the *client* only, talking to a separate authoritative
  backend over WebSockets — do not let the client compute money, combat,
  or diplomacy results once a server exists.
