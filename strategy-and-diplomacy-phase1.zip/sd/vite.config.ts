import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// If deployed as a PROJECT page (https://username.github.io/repo-name/),
// set base to '/repo-name/'. If a USER/ORG page (username.github.io), use '/'.
export default defineConfig({
  base: '/REPLACE_WITH_YOUR_REPO_NAME/',
  plugins: [react()],
})
