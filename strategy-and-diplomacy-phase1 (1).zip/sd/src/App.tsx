import { useEffect, useRef } from 'react'
import { useGameStore } from './state/gameStore'
import MainMenu from './components/MainMenu'
import NationCreator from './components/NationCreator'
import AssetLibrary from './components/AssetLibrary'
import TopBar from './components/TopBar'
import SideNav from './components/SideNav'
import StrategicMap from './components/StrategicMap'
import RightPanel from './components/RightPanel'

function useGameClock() {
  const tick = useGameStore((s) => s.tick)
  const lastRef = useRef<number | null>(null)

  useEffect(() => {
    let raf: number
    function loop(t: number) {
      if (lastRef.current !== null) {
        const deltaSeconds = (t - lastRef.current) / 1000
        tick(deltaSeconds)
      }
      lastRef.current = t
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [tick])
}

function GameScreen() {
  useGameClock()
  const world = useGameStore((s) => s.world)
  const playerCountryId = useGameStore((s) => s.playerCountryId)
  const nation = useGameStore((s) => s.nation)
  const selectedHexId = useGameStore((s) => s.selectedHexId)
  const selectHex = useGameStore((s) => s.selectHex)

  if (!world || !playerCountryId || !nation) return null

  return (
    <div className="game-screen">
      <TopBar />
      <div className="game-body">
        <SideNav />
        <StrategicMap
          world={world}
          selectedHexId={selectedHexId}
          playerCountryId={playerCountryId}
          onSelectHex={selectHex}
        />
        <RightPanel
          world={world}
          selectedHexId={selectedHexId}
          playerCountryId={playerCountryId}
          nation={nation}
        />
      </div>
    </div>
  )
}

export default function App() {
  const screen = useGameStore((s) => s.screen)

  if (screen === 'menu') return <MainMenu />
  if (screen === 'creator') return <NationCreator />
  if (screen === 'assets') return <AssetLibrary />
  return <GameScreen />
}
