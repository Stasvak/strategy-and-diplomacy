import { BorderSegment, Hex, WorldCountry, WorldData } from '../types'
import { generateFlagSpec } from '../flags/generateFlag'

// ---------------------------------------------------------------------
// Deterministic RNG so a given seed always produces the same world.
// ---------------------------------------------------------------------
function mulberry32(seed: number) {
  let a = seed
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

// Cheap continuous pseudo-noise (sum of sines) — good enough for an
// irregular, non-repeating coastline without pulling in a noise library.
function fakeNoise(x: number, y: number, seed: number) {
  const s = seed * 0.0001
  const v =
    Math.sin(x * 0.012 + s * 3 + 1.7) * Math.cos(y * 0.014 + s * 2 - 2.1) +
    Math.sin((x - y) * 0.008 + s * 5 + 4.4) * 0.6 +
    Math.sin((x + y) * 0.02 + s * 7 - 1.1) * 0.4
  return v / 2 // roughly -1..1
}

const HEX_SIZE = 26
const SQRT3 = Math.sqrt(3)

function axialToPixel(q: number, r: number): [number, number] {
  const x = HEX_SIZE * 1.5 * q
  const y = HEX_SIZE * SQRT3 * (r + q / 2)
  return [x, y]
}

function hexCorners(cx: number, cy: number): [number, number][] {
  const corners: [number, number][] = []
  for (let i = 0; i < 6; i++) {
    const angle = (Math.PI / 180) * (60 * i)
    corners.push([
      Math.round((cx + HEX_SIZE * Math.cos(angle)) * 100) / 100,
      Math.round((cy + HEX_SIZE * Math.sin(angle)) * 100) / 100,
    ])
  }
  return corners
}

// Deterministic hash-based jitter. Because it's keyed on the *rounded
// corner position* rather than which hex/vertex-index generated it,
// two hexes that nominally share a corner independently compute the
// identical jittered position — so the mesh stays seamless while still
// looking organic instead of a grid.
function jitterCorner(x: number, y: number, seed: number): [number, number] {
  const k = `${x.toFixed(1)}_${y.toFixed(1)}`
  let h = seed
  for (let i = 0; i < k.length; i++) h = (h * 31 + k.charCodeAt(i)) | 0
  const r1 = mulberry32(h)()
  const r2 = mulberry32(h ^ 0x9e3779b9)()
  const amount = HEX_SIZE * 0.34
  return [x + (r1 - 0.5) * amount, y + (r2 - 0.5) * amount]
}

const COUNTRY_NAMES = [
  'Valtoria', 'Kessrath', 'Northfall Union', 'Draven Reach', 'Ashmoor',
  'Corvane Federation', 'Thornwick', 'Veyra Basin', 'Halgard', 'Ironspire',
  'Duskvale', 'Sarrow Isles', 'Brackenhold', 'Vantor', 'Greywater',
  'Oskeld', 'Falkrest', 'Umberlane', 'Ristow', 'Caldeen',
  'Marrow Fen', 'Silverkeep', 'Yendor', 'Ashgate Republic', 'Nordhelm',
]

const COUNTRY_COLORS = [
  '#7a8b6f', '#a3684f', '#5c7d8a', '#8a6a4f', '#6f7a8b',
  '#8a5c6a', '#5c8a6f', '#8a7a4f', '#6a5c8a', '#7a8a4f',
  '#4f6a8a', '#8a4f5c', '#4f8a7a', '#8a6f4f', '#5c6a8a',
]

export interface GeneratedWorld {
  world: WorldData
  neutralCountryIds: string[]
}

export function generateWorld(seed: number, playerColor: string): GeneratedWorld {
  const rand = mulberry32(seed)
  const hexes: Record<string, Hex> = {}

  const COLS = 22
  const ROWS = 16
  const landHexList: { q: number; r: number; x: number; y: number }[] = []

  // Two continent blobs so the landmass reads as "world geography",
  // not a single circular island.
  const continents = [
    { cx: -260, cy: -60, rx: 340, ry: 260 },
    { cx: 320, cy: 140, rx: 300, ry: 230 },
  ]

  for (let q = -COLS; q <= COLS; q++) {
    for (let r = -ROWS; r <= ROWS; r++) {
      const [x, y] = axialToPixel(q, r)
      let falloff = 0
      for (const c of continents) {
        const d = Math.sqrt(((x - c.cx) / c.rx) ** 2 + ((y - c.cy) / c.ry) ** 2)
        falloff = Math.max(falloff, 1 - d)
      }
      const n = fakeNoise(x, y, seed)
      const value = falloff + n * 0.4
      if (value > 0.18) {
        landHexList.push({ q, r, x, y })
      }
    }
  }

  // Build hex records with jittered, seam-consistent corners.
  for (const h of landHexList) {
    const rawCorners = hexCorners(h.x, h.y)
    const corners = rawCorners.map(([cx, cy]) => jitterCorner(cx, cy, seed))
    const id = `${h.q},${h.r}`
    hexes[id] = { id, q: h.q, r: h.r, center: [h.x, h.y], corners, countryId: null }
  }

  // --- Assign land hexes to countries via nearest-seed partition ---
  const landIds = Object.keys(hexes)
  const targetCountries = Math.max(8, Math.min(18, Math.floor(landIds.length / 14)))
  const shuffled = [...landIds].sort(() => rand() - 0.5)
  const seedIds = shuffled.slice(0, targetCountries)

  const countries: Record<string, WorldCountry> = {}
  const usedNames = new Set<string>()
  seedIds.forEach((seedId, idx) => {
    let name = COUNTRY_NAMES[idx % COUNTRY_NAMES.length]
    while (usedNames.has(name)) name = name + ' II'
    usedNames.add(name)
    const id = `country_${idx}`
    const color = COUNTRY_COLORS[idx % COUNTRY_COLORS.length]
    countries[id] = {
      id,
      name,
      color,
      isPlayer: false,
      hexIds: [],
      capitalHexId: seedId,
      flag: generateFlagSpec(seed + idx * 7919, color),
    }
  })

  for (const id of landIds) {
    const hex = hexes[id]
    let best = seedIds[0]
    let bestDist = Infinity
    for (const seedId of seedIds) {
      const sh = hexes[seedId]
      const d = (hex.center[0] - sh.center[0]) ** 2 + (hex.center[1] - sh.center[1]) ** 2
      if (d < bestDist) { bestDist = d; best = seedId }
    }
    const countryIdx = seedIds.indexOf(best)
    const countryId = `country_${countryIdx}`
    hex.countryId = countryId
    countries[countryId].hexIds.push(id)
  }

  // --- Border extraction: group edges by shared (rounded) corner pair ---
  type EdgeInfo = { hexIds: string[] }
  const edgeMap = new Map<string, EdgeInfo>()
  const edgePos = new Map<string, [[number, number], [number, number]]>()

  function edgeKey(p1: [number, number], p2: [number, number]) {
    const a = `${p1[0].toFixed(1)},${p1[1].toFixed(1)}`
    const b = `${p2[0].toFixed(1)},${p2[1].toFixed(1)}`
    return a < b ? `${a}|${b}` : `${b}|${a}`
  }

  for (const id of landIds) {
    const hex = hexes[id]
    for (let i = 0; i < 6; i++) {
      const p1 = hex.corners[i]
      const p2 = hex.corners[(i + 1) % 6]
      const key = edgeKey(p1, p2)
      if (!edgeMap.has(key)) {
        edgeMap.set(key, { hexIds: [] })
        edgePos.set(key, [p1, p2])
      }
      edgeMap.get(key)!.hexIds.push(id)
    }
  }

  const borders: BorderSegment[] = []
  for (const [key, info] of edgeMap.entries()) {
    const [p1, p2] = edgePos.get(key)!
    if (info.hexIds.length === 1) {
      borders.push({ a: p1, b: p2, kind: 'coast' })
    } else if (info.hexIds.length === 2) {
      const [h1, h2] = info.hexIds
      if (hexes[h1].countryId !== hexes[h2].countryId) {
        borders.push({ a: p1, b: p2, kind: 'border' })
      }
    }
  }

  // World bounds for the SVG viewBox
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity
  for (const id of landIds) {
    for (const [cx, cy] of hexes[id].corners) {
      minX = Math.min(minX, cx); maxX = Math.max(maxX, cx)
      minY = Math.min(minY, cy); maxY = Math.max(maxY, cy)
    }
  }
  const pad = HEX_SIZE * 3
  const bounds = { width: maxX - minX + pad * 2, height: maxY - minY + pad * 2 }
  const offsetX = -minX + pad
  const offsetY = -minY + pad
  for (const id of landIds) {
    hexes[id].center = [hexes[id].center[0] + offsetX, hexes[id].center[1] + offsetY]
    hexes[id].corners = hexes[id].corners.map(([x, y]) => [x + offsetX, y + offsetY])
  }
  for (const b of borders) {
    b.a = [b.a[0] + offsetX, b.a[1] + offsetY]
    b.b = [b.b[0] + offsetX, b.b[1] + offsetY]
  }

  const neutralCountryIds = Object.keys(countries).filter(
    (id) => countries[id].hexIds.length >= 4
  )

  return {
    world: { hexes, countries, borders, bounds },
    neutralCountryIds,
  }
}
