import { FlagPattern, FlagSpec } from '../types'

function mulberry32(seed: number) {
  let a = seed
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

const PATTERNS: FlagPattern[] = [
  'horizontal-stripes', 'vertical-stripes', 'diagonal-cross',
  'cross', 'canton-stripes', 'triband',
]

// A restrained, plausible-looking palette (avoids neon/random RGB soup).
const PALETTE = [
  '#1c3d5a', '#8a1c2b', '#c7a35a', '#2f5233', '#5c3d1c',
  '#3d3d5c', '#a34a2f', '#1c5a4a', '#5a1c4a', '#3d5a1c',
  '#e8e4d8', '#1c1c1c', '#7a8b6f', '#5c7d8a', '#8a5c2f',
]

function hashSeed(str: string): number {
  let h = 0
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) | 0
  return h
}

/**
 * Deterministic procedural flag for AI nations (or as a suggestion for the
 * player). If `baseColor` is provided, the flag is built around it plus one
 * or two complementary tones instead of a fully random palette — used for
 * the player's own nation so the flag matches the colour they picked.
 */
export function generateFlagSpec(seedInput: string | number, baseColor?: string): FlagSpec {
  const seed = typeof seedInput === 'number' ? seedInput : hashSeed(seedInput)
  const rand = mulberry32(seed)

  const pattern = PATTERNS[Math.floor(rand() * PATTERNS.length)]

  let colors: string[]
  if (baseColor) {
    const others = PALETTE.filter((c) => c.toLowerCase() !== baseColor.toLowerCase())
    const secondary = others[Math.floor(rand() * others.length)]
    const tertiary = others[Math.floor(rand() * others.length)]
    colors = [baseColor, secondary, tertiary]
  } else {
    const shuffled = [...PALETTE].sort(() => rand() - 0.5)
    colors = shuffled.slice(0, 3)
  }

  return { kind: 'generated', pattern, colors }
}

/**
 * Resizes an uploaded image down to a small flag-sized canvas and returns a
 * compressed data URL, so a phone photo doesn't blow past localStorage
 * limits or bloat the save file.
 */
export function resizeImageToFlag(file: File, maxWidth = 300, maxHeight = 200): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onerror = () => reject(new Error('Could not read file'))
    reader.onload = () => {
      const img = new Image()
      img.onerror = () => reject(new Error('Could not decode image'))
      img.onload = () => {
        const scale = Math.min(maxWidth / img.width, maxHeight / img.height, 1)
        const w = Math.max(1, Math.round(img.width * scale))
        const h = Math.max(1, Math.round(img.height * scale))
        const canvas = document.createElement('canvas')
        canvas.width = w
        canvas.height = h
        const ctx = canvas.getContext('2d')
        if (!ctx) { reject(new Error('Canvas unavailable')); return }
        ctx.drawImage(img, 0, 0, w, h)
        resolve(canvas.toDataURL('image/jpeg', 0.82))
      }
      img.src = reader.result as string
    }
    reader.readAsDataURL(file)
  })
}
