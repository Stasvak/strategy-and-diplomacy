export interface Government {
  id: string
  name: string
}

export interface Ideology {
  id: string
  name: string
}

export interface Trait {
  id: string
  name: string
  description: string
  cost: number // positive = consumes budget points, negative = refunds points
}

export type FlagPattern =
  | 'horizontal-stripes'
  | 'vertical-stripes'
  | 'diagonal-cross'
  | 'cross'
  | 'canton-stripes'
  | 'triband'

export type FlagSpec =
  | { kind: 'generated'; pattern: FlagPattern; colors: string[] }
  | { kind: 'custom'; dataUrl: string }

export interface NationDraft {
  officialName: string
  commonName: string
  capitalName: string
  leaderName: string
  leaderTitle: string
  currencyName: string
  demonym: string
  motto: string
  color: string
  governmentId: string
  ideologyId: string
  traitIds: string[]
  flag: FlagSpec
}

export interface Hex {
  id: string
  q: number
  r: number
  center: [number, number]
  corners: [number, number][]
  countryId: string | null // null = ocean/unclaimed
}

export type BorderKind = 'coast' | 'border'

export interface BorderSegment {
  a: [number, number]
  b: [number, number]
  kind: BorderKind
}

export interface WorldCountry {
  id: string
  name: string
  color: string
  isPlayer: boolean
  hexIds: string[]
  capitalHexId: string
  flag: FlagSpec
}

export interface WorldData {
  hexes: Record<string, Hex>
  countries: Record<string, WorldCountry>
  borders: BorderSegment[]
  bounds: { width: number; height: number }
}

export interface GameClock {
  totalHours: number // simulation time, hours since campaign start
  paused: boolean
  speed: 1 | 2 | 4 | 8
}

export type Screen = 'menu' | 'creator' | 'game' | 'assets'

export interface SaveFile {
  version: 1
  nation: NationDraft
  world: WorldData
  playerCountryId: string
  clock: GameClock
}
