interface IconProps {
  size?: number
  color?: string
}

const DEFAULT_COLOR = '#dfe4e6'

export function FactoryIcon({ size = 24, color = DEFAULT_COLOR }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.5}>
      <path d="M3 19 V11 L8 14 V11 L13 14 V11 L18 14 V8 L21 8 V19 Z" />
      <line x1={3} y1={19} x2={21} y2={19} />
    </svg>
  )
}

export function FarmIcon({ size = 24, color = DEFAULT_COLOR }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.5}>
      <path d="M4 20 L4 12 L12 6 L20 12 L20 20 Z" />
      <line x1={9} y1={20} x2={9} y2={13} />
      <line x1={15} y1={20} x2={15} y2={13} />
    </svg>
  )
}

export function MineIcon({ size = 24, color = DEFAULT_COLOR }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.5}>
      <path d="M3 20 L9 8 L15 20 Z" />
      <path d="M11 20 L16 10 L21 20 Z" />
    </svg>
  )
}

export function PowerPlantIcon({ size = 24, color = DEFAULT_COLOR }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.5}>
      <rect x={4} y={10} width={16} height={10} />
      <polygon points="13,3 8,13 12,13 10,21 17,10 13,10" fill={color} stroke="none" />
    </svg>
  )
}

export function ResearchLabIcon({ size = 24, color = DEFAULT_COLOR }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.5}>
      <path d="M10 3 V10 L4 20 H20 L14 10 V3" />
      <line x1={9} y1={3} x2={15} y2={3} />
    </svg>
  )
}

export function PortIcon({ size = 24, color = DEFAULT_COLOR }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.5}>
      <line x1={12} y1={2} x2={12} y2={14} />
      <path d="M12 5 L18 8 L12 8 Z" fill={color} stroke="none" />
      <path d="M3 20 Q7 16 12 20 Q17 24 21 20" />
    </svg>
  )
}

export function RefineryIcon({ size = 24, color = DEFAULT_COLOR }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.5}>
      <rect x={5} y={12} width={4} height={8} />
      <rect x={11} y={8} width={4} height={12} />
      <rect x={17} y={15} width={3} height={5} />
      <line x1={7} y1={12} x2={7} y2={4} />
      <circle cx={7} cy={3} r={1.2} fill={color} stroke="none" />
    </svg>
  )
}
