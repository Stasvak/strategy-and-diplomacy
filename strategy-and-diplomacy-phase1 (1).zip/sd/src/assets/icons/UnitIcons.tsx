interface IconProps {
  size?: number
  color?: string
}

const DEFAULT_COLOR = '#dfe4e6'

export function InfantryIcon({ size = 24, color = DEFAULT_COLOR }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <rect x={2} y={2} width={20} height={20} fill="none" stroke={color} strokeWidth={1.5} />
      <line x1={4} y1={4} x2={20} y2={20} stroke={color} strokeWidth={1.5} />
      <line x1={20} y1={4} x2={4} y2={20} stroke={color} strokeWidth={1.5} />
    </svg>
  )
}

export function ArmorIcon({ size = 24, color = DEFAULT_COLOR }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <rect x={2} y={2} width={20} height={20} fill="none" stroke={color} strokeWidth={1.5} />
      <ellipse cx={12} cy={12} rx={7} ry={5} fill="none" stroke={color} strokeWidth={1.5} />
    </svg>
  )
}

export function ArtilleryIcon({ size = 24, color = DEFAULT_COLOR }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <rect x={2} y={2} width={20} height={20} fill="none" stroke={color} strokeWidth={1.5} />
      <circle cx={12} cy={12} r={3} fill={color} />
      <line x1={12} y1={12} x2={19} y2={5} stroke={color} strokeWidth={1.5} />
    </svg>
  )
}

export function NavalIcon({ size = 24, color = DEFAULT_COLOR }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <rect x={2} y={2} width={20} height={20} fill="none" stroke={color} strokeWidth={1.5} />
      <path d="M5 14 L19 14 L16 19 L8 19 Z" fill="none" stroke={color} strokeWidth={1.5} />
      <line x1={12} y1={14} x2={12} y2={6} stroke={color} strokeWidth={1.5} />
    </svg>
  )
}

export function AirIcon({ size = 24, color = DEFAULT_COLOR }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <rect x={2} y={2} width={20} height={20} fill="none" stroke={color} strokeWidth={1.5} />
      <path d="M12 5 L15 12 L20 14 L15 15 L12 20 L9 15 L4 14 L9 12 Z" fill="none" stroke={color} strokeWidth={1.4} />
    </svg>
  )
}

export function SpecialForcesIcon({ size = 24, color = DEFAULT_COLOR }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <rect x={2} y={2} width={20} height={20} fill="none" stroke={color} strokeWidth={1.5} />
      <line x1={4} y1={4} x2={20} y2={20} stroke={color} strokeWidth={1.5} />
      <line x1={20} y1={4} x2={4} y2={20} stroke={color} strokeWidth={1.5} />
      <circle cx={12} cy={12} r={2.4} fill={color} />
    </svg>
  )
}
