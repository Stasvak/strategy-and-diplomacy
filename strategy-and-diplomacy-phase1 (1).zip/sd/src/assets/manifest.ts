import {
  InfantryIcon, ArmorIcon, ArtilleryIcon, NavalIcon, AirIcon, SpecialForcesIcon,
} from './icons/UnitIcons'
import {
  FactoryIcon, FarmIcon, MineIcon, PowerPlantIcon, ResearchLabIcon, PortIcon, RefineryIcon,
} from './icons/BuildingIcons'

export interface AssetDefinition {
  id: string
  label: string
  category: 'unit' | 'building'
  Icon: (props: { size?: number; color?: string }) => JSX.Element
}

// Data-driven registry: Phase 2 (buildings) and Phase 3 (units) should look
// unit/building visuals up by id here rather than importing icon components
// directly, so new categories can be added without touching gameplay code.
export const ASSET_MANIFEST: AssetDefinition[] = [
  { id: 'unit.infantry', label: 'Infantry Corps', category: 'unit', Icon: InfantryIcon },
  { id: 'unit.armor', label: 'Armor Division', category: 'unit', Icon: ArmorIcon },
  { id: 'unit.artillery', label: 'Artillery Battery', category: 'unit', Icon: ArtilleryIcon },
  { id: 'unit.naval', label: 'Naval Task Force', category: 'unit', Icon: NavalIcon },
  { id: 'unit.air', label: 'Air Wing', category: 'unit', Icon: AirIcon },
  { id: 'unit.special_forces', label: 'Special Forces', category: 'unit', Icon: SpecialForcesIcon },

  { id: 'building.factory', label: 'Civilian Factory', category: 'building', Icon: FactoryIcon },
  { id: 'building.farm', label: 'Farmland', category: 'building', Icon: FarmIcon },
  { id: 'building.mine', label: 'Mine', category: 'building', Icon: MineIcon },
  { id: 'building.power_plant', label: 'Power Plant', category: 'building', Icon: PowerPlantIcon },
  { id: 'building.research_lab', label: 'Research Lab', category: 'building', Icon: ResearchLabIcon },
  { id: 'building.port', label: 'Port', category: 'building', Icon: PortIcon },
  { id: 'building.refinery', label: 'Refinery', category: 'building', Icon: RefineryIcon },
]

export function getAsset(id: string): AssetDefinition | undefined {
  return ASSET_MANIFEST.find((a) => a.id === id)
}
