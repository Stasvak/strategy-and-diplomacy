import type { CSSProperties } from 'react'
import { FlagSpec } from '../types'

interface Props {
  flag: FlagSpec
  width?: number
  height?: number
  rounded?: boolean
}

const W = 60
const H = 40

function PatternBody({ flag }: { flag: Extract<FlagSpec, { kind: 'generated' }> }) {
  const [c1, c2, c3] = flag.colors

  switch (flag.pattern) {
    case 'horizontal-stripes':
      return (
        <>
          <rect width={W} height={H} fill={c1} />
          <rect y={H / 3} width={W} height={H / 3} fill={c2} />
        </>
      )
    case 'vertical-stripes':
      return (
        <>
          <rect width={W} height={H} fill={c1} />
          <rect x={W / 3} width={W / 3} height={H} fill={c2} />
        </>
      )
    case 'triband':
      return (
        <>
          <rect width={W} height={H} fill={c1} />
          <rect x={0} width={W / 3} height={H} fill={c2} />
          <rect x={(2 * W) / 3} width={W / 3} height={H} fill={c3} />
        </>
      )
    case 'cross':
      return (
        <>
          <rect width={W} height={H} fill={c1} />
          <rect x={W * 0.38} width={W * 0.24} height={H} fill={c2} />
          <rect y={H * 0.36} width={W} height={H * 0.28} fill={c2} />
        </>
      )
    case 'diagonal-cross':
      return (
        <>
          <rect width={W} height={H} fill={c1} />
          <polygon points={`0,0 ${W * 0.18},0 ${W},${H * 0.82} ${W},${H} ${W * 0.82},${H} 0,${H * 0.18}`} fill={c2} />
          <polygon points={`${W},0 ${W},${H * 0.18} ${W * 0.18},${H} 0,${H} 0,${H * 0.82} ${W * 0.82},0`} fill={c2} />
        </>
      )
    case 'canton-stripes':
      return (
        <>
          <rect width={W} height={H} fill={c1} />
          <rect y={H / 2} width={W} height={H / 2} fill={c2} />
          <rect width={W * 0.42} height={H / 2} fill={c3} />
        </>
      )
    default:
      return <rect width={W} height={H} fill={c1} />
  }
}

export default function FlagIcon({ flag, width = 30, height = 20, rounded = false }: Props) {
  const style: CSSProperties = {
    border: '1px solid #2a3134',
    borderRadius: rounded ? 2 : 0,
    flexShrink: 0,
    display: 'block',
  }

  if (flag.kind === 'custom') {
    return (
      <img
        src={flag.dataUrl}
        alt="Nation flag"
        width={width}
        height={height}
        style={{ ...style, objectFit: 'cover' }}
      />
    )
  }

  return (
    <svg width={width} height={height} viewBox={`0 0 ${W} ${H}`} style={style}>
      <PatternBody flag={flag} />
    </svg>
  )
}
