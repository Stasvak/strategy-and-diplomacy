import { useGameStore } from '../state/gameStore'

export default function MainMenu() {
  const goToCreator = useGameStore((s) => s.goToCreator)
  const goToAssetLibrary = useGameStore((s) => s.goToAssetLibrary)
  const load = useGameStore((s) => s.load)
  const hasSave = useGameStore((s) => s.hasSave())

  return (
    <div className="menu-screen">
      <h1>STRATEGY &amp; DIPLOMACY</h1>
      <div className="rule" />
      <div className="tagline">Phase 1 Prototype</div>

      <div className="menu-actions">
        <button className="primary" onClick={goToCreator}>New Campaign</button>
        <button disabled={!hasSave} onClick={() => load()}>Continue Campaign</button>
        <button disabled title="Multiplayer requires a server-authoritative backend — Phase 8">
          Multiplayer (Phase 8 — not built yet)
        </button>
        <button onClick={goToAssetLibrary}>Asset Library (preview)</button>
      </div>

      <p className="menu-note">
        This is a single-player, client-only Phase 1 build: nation creation, a real
        procedurally-generated map, and a live game clock. Economy, military,
        diplomacy, and multiplayer are later phases and are not implemented yet —
        their nav entries say so rather than pretending to work.
      </p>
    </div>
  )
}
