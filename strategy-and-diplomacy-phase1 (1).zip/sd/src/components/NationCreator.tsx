import React, { useMemo, useState } from 'react'
import { useGameStore } from '../state/gameStore'
import { GOVERNMENTS, IDEOLOGIES } from '../data/governments'
import { STARTING_BUDGET, TRAITS } from '../data/traits'
import { FlagSpec, NationDraft } from '../types'
import { generateFlagSpec, resizeImageToFlag } from '../flags/generateFlag'
import FlagIcon from './FlagIcon'

export default function NationCreator() {
  const startCampaign = useGameStore((s) => s.startCampaign)
  const goToMenu = useGameStore((s) => s.goToMenu)

  const [officialName, setOfficialName] = useState('')
  const [commonName, setCommonName] = useState('')
  const [capitalName, setCapitalName] = useState('')
  const [leaderName, setLeaderName] = useState('')
  const [leaderTitle, setLeaderTitle] = useState('President')
  const [currencyName, setCurrencyName] = useState('')
  const [demonym, setDemonym] = useState('')
  const [motto, setMotto] = useState('')
  const [color, setColor] = useState('#4a9d94')
  const [governmentId, setGovernmentId] = useState(GOVERNMENTS[0].id)
  const [ideologyId, setIdeologyId] = useState(IDEOLOGIES[0].id)
  const [traitIds, setTraitIds] = useState<string[]>([])
  const [flag, setFlag] = useState<FlagSpec>(() => generateFlagSpec(Date.now(), '#4a9d94'))
  const [flagError, setFlagError] = useState<string | null>(null)

  function regenerateFlag() {
    setFlag(generateFlagSpec(Math.floor(Math.random() * 1_000_000), color))
  }

  async function handleFlagUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) {
      setFlagError('Please choose an image file.')
      return
    }
    try {
      const dataUrl = await resizeImageToFlag(file)
      setFlag({ kind: 'custom', dataUrl })
      setFlagError(null)
    } catch {
      setFlagError('Could not load that image — try a different file.')
    }
  }

  const spent = useMemo(
    () => TRAITS.filter((t) => traitIds.includes(t.id)).reduce((sum, t) => sum + t.cost, 0),
    [traitIds]
  )
  const remaining = STARTING_BUDGET - spent

  function toggleTrait(id: string, cost: number) {
    const isSelected = traitIds.includes(id)
    if (isSelected) {
      setTraitIds(traitIds.filter((t) => t !== id))
      return
    }
    // Refund traits (negative cost) never blocked; positive-cost traits
    // blocked if they'd push the budget negative.
    if (cost > 0 && remaining - cost < 0) return
    setTraitIds([...traitIds, id])
  }

  const canConfirm = officialName.trim().length > 0 && commonName.trim().length > 0

  function handleConfirm() {
    const draft: NationDraft = {
      officialName: officialName.trim(),
      commonName: commonName.trim(),
      capitalName: capitalName.trim() || 'Capital City',
      leaderName: leaderName.trim() || 'Unnamed Leader',
      leaderTitle: leaderTitle.trim() || 'Leader',
      currencyName: currencyName.trim() || 'Credit',
      demonym: demonym.trim() || commonName.trim(),
      motto: motto.trim(),
      color,
      governmentId,
      ideologyId,
      traitIds,
      flag,
    }
    startCampaign(draft)
  }

  return (
    <div className="creator-screen">
      <h1>Found Your Nation</h1>
      <div className="subtitle">Every field here is yours to define — nothing is locked to a preset country.</div>

      <div className="budget-bar">
        <span>National creation budget</span>
        <span className={`amount mono ${remaining < 0 ? 'negative' : ''}`}>{remaining} / {STARTING_BUDGET}</span>
      </div>

      <div className="field-group">
        <div className="section-label">Identity</div>
        <div className="two-col">
          <div className="field-row">
            <label>Official Name</label>
            <input type="text" value={officialName} onChange={(e) => setOfficialName(e.target.value)} placeholder="Federal Republic of Asteria" />
          </div>
          <div className="field-row">
            <label>Common Name</label>
            <input type="text" value={commonName} onChange={(e) => setCommonName(e.target.value)} placeholder="Asteria" />
          </div>
        </div>
        <div className="two-col">
          <div className="field-row">
            <label>Capital City</label>
            <input type="text" value={capitalName} onChange={(e) => setCapitalName(e.target.value)} placeholder="Asterport" />
          </div>
          <div className="field-row">
            <label>Demonym</label>
            <input type="text" value={demonym} onChange={(e) => setDemonym(e.target.value)} placeholder="Asterian" />
          </div>
        </div>
        <div className="field-row">
          <label>National Motto (optional)</label>
          <input type="text" value={motto} onChange={(e) => setMotto(e.target.value)} placeholder="Strength Through Unity" />
        </div>
        <div className="field-row">
          <label>National Colour</label>
          <input type="color" value={color} onChange={(e) => setColor(e.target.value)} />
        </div>
      </div>

      <div className="field-group">
        <div className="section-label">Flag</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 12 }}>
          <FlagIcon flag={flag} width={72} height={48} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <button
              type="button"
              onClick={regenerateFlag}
              style={{ background: 'transparent', border: '1px solid #2a3134', color: '#dfe4e6', padding: '7px 12px', fontSize: 11, letterSpacing: '0.06em', textTransform: 'uppercase' }}
            >
              Generate New Flag
            </button>
            <label style={{ background: 'transparent', border: '1px solid #2a3134', color: '#dfe4e6', padding: '7px 12px', fontSize: 11, letterSpacing: '0.06em', textTransform: 'uppercase', textAlign: 'center', cursor: 'pointer' }}>
              Upload From Photos
              <input type="file" accept="image/*" onChange={handleFlagUpload} style={{ display: 'none' }} />
            </label>
          </div>
        </div>
        {flagError && <div style={{ color: '#a6503f', fontSize: 11, marginBottom: 8 }}>{flagError}</div>}
        <div style={{ fontSize: 11, color: '#8b979c', lineHeight: 1.5 }}>
          Generated flags are built from your national colour. AI nations always get
          a randomly generated flag — this is the only place you can upload your own image.
        </div>
      </div>

      <div className="field-group">
        <div className="section-label">Leadership &amp; Currency</div>
        <div className="two-col">
          <div className="field-row">
            <label>Leader Name</label>
            <input type="text" value={leaderName} onChange={(e) => setLeaderName(e.target.value)} placeholder="Elena Voss" />
          </div>
          <div className="field-row">
            <label>Leader Title</label>
            <input type="text" value={leaderTitle} onChange={(e) => setLeaderTitle(e.target.value)} placeholder="President" />
          </div>
        </div>
        <div className="field-row">
          <label>Currency Name</label>
          <input type="text" value={currencyName} onChange={(e) => setCurrencyName(e.target.value)} placeholder="Asterian Crown" />
        </div>
      </div>

      <div className="field-group">
        <div className="section-label">Government</div>
        <div className="two-col">
          <div className="field-row">
            <label>Government Type</label>
            <select value={governmentId} onChange={(e) => setGovernmentId(e.target.value)}>
              {GOVERNMENTS.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
            </select>
          </div>
          <div className="field-row">
            <label>Political Ideology</label>
            <select value={ideologyId} onChange={(e) => setIdeologyId(e.target.value)}>
              {IDEOLOGIES.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
            </select>
          </div>
        </div>
      </div>

      <div className="field-group">
        <div className="section-label">National Traits (spend or refund budget)</div>
        {TRAITS.map((t) => {
          const selected = traitIds.includes(t.id)
          const disabled = !selected && t.cost > 0 && remaining - t.cost < 0
          return (
            <div
              key={t.id}
              className={`trait-card ${selected ? 'selected' : ''}`}
              style={{ opacity: disabled ? 0.4 : 1 }}
              onClick={() => !disabled && toggleTrait(t.id, t.cost)}
            >
              <input type="checkbox" checked={selected} readOnly disabled={disabled} />
              <div>
                <div className="trait-name">{t.name}</div>
                <div className="trait-desc">{t.description}</div>
              </div>
              <div className={`trait-cost mono ${t.cost > 0 ? 'cost' : 'refund'}`}>
                {t.cost > 0 ? `-${t.cost}` : `+${Math.abs(t.cost)}`}
              </div>
            </div>
          )
        })}
      </div>

      <div className="creator-actions">
        <button onClick={goToMenu}>Back</button>
        <button className="primary" disabled={!canConfirm} onClick={handleConfirm}>
          Generate World &amp; Begin
        </button>
      </div>
    </div>
  )
}
