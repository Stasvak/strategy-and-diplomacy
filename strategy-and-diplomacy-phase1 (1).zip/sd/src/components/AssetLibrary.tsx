import { useState } from 'react'
import { ASSET_MANIFEST } from '../assets/manifest'
import { generateFlagSpec } from '../flags/generateFlag'
import FlagIcon from './FlagIcon'
import { useGameStore } from '../state/gameStore'

export default function AssetLibrary() {
  const goToMenu = useGameStore((s) => s.goToMenu)
  const [flagSeed, setFlagSeed] = useState(1)

  const sampleFlags = Array.from({ length: 8 }, (_, i) => generateFlagSpec(flagSeed * 100 + i))
  const units = ASSET_MANIFEST.filter((a) => a.category === 'unit')
  const buildings = ASSET_MANIFEST.filter((a) => a.category === 'building')

  return (
    <div className="creator-screen">
      <h1>Asset Library</h1>
      <div className="subtitle">
        Preview of the 2D icon set and flag generator. Real 3D models/artwork
        would replace these later without any code changes — see the manifest
        at <code>src/assets/manifest.ts</code>.
      </div>

      <div className="field-group">
        <div className="section-label">Generated Flags (AI nations get one of these, seeded)</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 10 }}>
          {sampleFlags.map((f, i) => <FlagIcon key={i} flag={f} width={64} height={42} />)}
        </div>
        <button
          onClick={() => setFlagSeed((s) => s + 1)}
          style={{ background: 'transparent', border: '1px solid #2a3134', color: '#dfe4e6', padding: '7px 12px', fontSize: 11, textTransform: 'uppercase' }}
        >
          Reroll Examples
        </button>
      </div>

      <div className="field-group">
        <div className="section-label">Unit Icons</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 18 }}>
          {units.map((u) => (
            <div key={u.id} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, width: 84 }}>
              <div style={{ border: '1px solid #2a3134', padding: 10, background: '#14181a' }}>
                <u.Icon size={28} color="#c7a35a" />
              </div>
              <span style={{ fontSize: 10, color: '#8b979c', textAlign: 'center' }}>{u.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="field-group">
        <div className="section-label">Building Icons</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 18 }}>
          {buildings.map((b) => (
            <div key={b.id} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, width: 84 }}>
              <div style={{ border: '1px solid #2a3134', padding: 10, background: '#14181a' }}>
                <b.Icon size={28} color="#c7a35a" />
              </div>
              <span style={{ fontSize: 10, color: '#8b979c', textAlign: 'center' }}>{b.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="creator-actions">
        <button className="primary" onClick={goToMenu}>Back to Menu</button>
      </div>
    </div>
  )
}
